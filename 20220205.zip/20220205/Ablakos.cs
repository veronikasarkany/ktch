using System.Windows.Forms;
using System;
/*Mivel az alap rettentő kevés dolgot tartalmaz, az egyéb sajátosságok a net.Framework terminológiája alapján un. NÉVTEREk használatbavételével lesz  pótolható*/
class Ablak{
	static int db=0;
	static Form f;
	static void Main(){
	f = new Form(); //a System.Windows.Forms.Form egy példányát hozza létre
	f.Text="Ablakos (C) 2022."; //az ablakpéldány címsorába kerülő szöveg megadása
	f.Width=800; //ablak szélessége
	f.Height=600; //magassága pixel-ben megadva
	//itt helyezzük el a szükséges opció gombokat
	for (int sor=1; sor<=9; sor++){
		for(int oszlop=1; oszlop<=10; oszlop++){
			CheckBox cb = new CheckBox();
			cb.Text =""+((sor-1)*10+oszlop); //1,2,3...89.90
			cb.Width=50;
			cb.Height=50;		
			cb.Left=oszlop*50; //vizszintes
			cb.Top=sor*50; //függőleges koordiánták
			cb.Click+=Kattintas;
			f.Controls.Add(cb);
		}
	}
	Button b=new Button();
	b.Width+=20;
	b.Text="Lottósorsolás";
	b.Left=600;
	b.Top=50;
	b.Click+=new EventHandler(Lottosorsolas);
	b.Enabled=false;
	f.Controls.Add(b);
	f.ShowDialog(); //az ablak láthatová tétele
	}
	static void Kattintas(object o, EventArgs e)
	{
		//MessageBox.Show(o.ToString());
		//CheckBox cb=(CheckBox)o; //cast-olás , tipuskényszerités
		CheckBox cb=o as CheckBox;  //cast-olás , tipuskényszerités
		//string uzenet=$"{cb.Text}:{cb.CheckState==1?"BE":"KI"}";
		//string uzenet=cb.Text+":"+(cb.CheckState==CheckState.Checked?"BE":"KI");
		//MessageBox.Show(uzenet);
		if(cb.Checked) db++; else db--;
		if(db==5)
		{
			foreach(Control c in f.Controls)
			{
				if(c is CheckBox)
				{ 
					if(!((CheckBox)c).Checked) c.Enabled=false; 
				} 
				else if (c is Button) c.Enabled=true;
			}
		}
		else 
		{
			foreach(Control c in f.Controls) if(c is CheckBox) c.Enabled=true;
		}
		
	}
	static void Lottosorsolas(object o, EventArgs e)
	{
		Random r= new Random();
		int[] szamok=new int[5]; //ekkor 5db 0-át tartalmas
		for(int i=0; i<szamok.Length; i++)
		{
			szamok[i]=r.Next(1,91); //ilyenkor a 91 nem fordulhat elő (1;91) <=>(1;90)
		}
	}
	
}
