﻿using LottoAdat.Data;
using LottoAdat.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace AdatTeszt
{
    class Program
    {
        static void Main(string[] args)
        {
            string f= @"C:\Users\Attila\Desktop\2022.02.02(Kedd)\LottoSzamokHatos.csv";
            
            LottoAdatContext db = new LottoAdatContext();

            if (!db.LottoSzamok.Any())
            {
                string[] sorok = null;
                bool sikerult = true;
                try
                {
                    sorok = File.ReadAllLines(args[0]);
                }
                catch (Exception)
                {
                    sikerult = false;
                    Console.WriteLine("\a");
                    Console.WriteLine(@"Hibás a fájl paraméter! pl: c:\adat\adatok.txt");
                }
                if (sikerult)
                {
                    List<string> hibasSorok = new List<string>();

                    LottoSzam lsz = null;
                    bool sikeresLetrehozas = true;
                    foreach (var item in sorok)
                    {
                        sikeresLetrehozas = true;
                        try
                        {
                            lsz = new LottoSzam(item);
                        }
                        catch (Exception)
                        {
                            sikeresLetrehozas = false;
                        }
                        if (sikeresLetrehozas) db.LottoSzamok.Add(lsz);
                        else hibasSorok.Add(item);
                    }
                    db.SaveChanges();
                    File.WriteAllLines(
                        Path.Combine(
                            Path.GetDirectoryName(args[0]), "HibasSorok.csv"), hibasSorok);

                    Console.WriteLine($"Sikeresen importált sorok száma: {db.LottoSzamok.Count()}");
                    Console.WriteLine($"Sikertelenül importált sorok száma: {hibasSorok.Count()}");
                } // HA sikerült
            }
            else {
                Console.WriteLine("Az adattábla létezik!");
            }
            
            
            
            Console.WriteLine("Hello World!");
        }
    }
}
