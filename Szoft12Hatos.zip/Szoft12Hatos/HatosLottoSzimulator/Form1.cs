﻿using LottoAdat.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HatosLottoSzimulator
{
    public partial class Form1 : Form
    {

        List<int> tip = new List<int>();
        LottoAdatContext db = new LottoAdatContext();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btnSorsol.Enabled = false;
            for (int i = 1; i < 46; i++)
            {
                CheckBox box = new CheckBox();
                box.AutoSize = true;
                box.Text = i.ToString();
                box.Tag = i.ToString();
                box.Location = new Point(((i - 1) % 10) * 50 + 50, Convert.ToInt32((i - 1) / 10) * 50 + 50);
                box.CheckedChanged += checkBox1_CheckedChanged;
                this.Controls.Add(box);
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox box = (CheckBox)sender;
            if (box.Checked)
            {
                tip.Add(Convert.ToInt32(box.Text));
                if (tip.Count() == 6)
                {
                    btnSorsol.Enabled = true;
                    foreach (var item in this.Controls)
                    {
                        if (item.GetType().ToString() == "System.Windows.Forms.CheckBox")
                        {
                            CheckBox ujBox = (CheckBox)item;
                            if (!ujBox.Checked) ujBox.Enabled = false;

                        }
                        //MessageBox.Show(item.GetType().ToString());

                    }
                }
            }
            else
            {
                tip.Remove(Convert.ToInt32(box.Text));
                if (tip.Count() == 5)
                {
                    btnSorsol.Enabled = false;
                    foreach (var item in this.Controls)
                    {
                        if (item.GetType().ToString() == "System.Windows.Forms.CheckBox")
                        {
                            CheckBox ujBox = (CheckBox)item;
                            ujBox.Enabled = true;
                        }
                    }
                }               
            }
            label1.Text = string.Join(", ", tip.OrderBy(x => x));
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSorsol_Click(object sender, EventArgs e)
        {
            Random veletlen = new Random();
            HashSet<int> set = new HashSet<int>();

            do
            {
                //set.Add(veletlen.Next(1, 7));
                set.Add(veletlen.Next(1, 46));
            } while (set.Count()!=6);
            
            db.LottoSzamok.Add(new LottoAdat.Models.LottoSzam(string.Join(";",set)));
            db.SaveChanges();

            //label1.Text = string.Join(";", set);

            MessageBox.Show($"Találatok száma: {set.Intersect(tip).Count()}");
        }
    }
}
