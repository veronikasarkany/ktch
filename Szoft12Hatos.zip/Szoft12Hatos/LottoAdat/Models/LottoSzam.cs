﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LottoAdat.Models
{
    public class LottoSzam
    {
        public int Id { get; set; }
        public int Szam1 { get; set; }
        public int Szam2 { get; set; }
        public int Szam3 { get; set; }
        public int Szam4 { get; set; }
        public int Szam5 { get; set; }
        public int Szam6 { get; set; }

        public LottoSzam()
        {
        }

        public LottoSzam(string sor)
        {
            string[] tombSzoveg = sor.Trim().Split(";");
            if (tombSzoveg.Length == 6)
            {
                int[] tombSzam = new int[6];
                for (int i = 0; i < 6; i++)
                {
                    try
                    {
                        tombSzam[i] = Convert.ToInt32(tombSzoveg[i].Trim());
                    }
                    catch (Exception)
                    {
                        throw new ArgumentException("Nem konvertálható számmá", "sor");
                    }
                    if ( (tombSzam[i]<1) || (tombSzam[i] > 45) )
                        throw new ArgumentException("A szám nagysága nem megfelelő", "sor"); 
                }
                HashSet<int> halmaz = new HashSet<int>(tombSzam);
                if (halmaz.Count()!=6) throw new ArgumentException("Ismétlődő elemek az adatban", "sor");

                Szam1 = tombSzam[0];
                Szam2 = tombSzam[1];
                Szam3 = tombSzam[2];
                Szam4 = tombSzam[3];
                Szam5 = tombSzam[4];
                Szam6 = tombSzam[5];

            }
            else
            {
                throw new ArgumentException("Adatszám hibás","sor");
            }

           
        }
    }


}
